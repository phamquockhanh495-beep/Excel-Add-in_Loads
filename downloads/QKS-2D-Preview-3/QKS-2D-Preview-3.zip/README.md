# QKS 2D Preview 3 — Windows Excel 64-bit

Đóng mọi Excel, bỏ đăng ký XLL QKS cũ. Giải nén đầy đủ; Excel → File → Options → Add-ins → Manage Excel Add-ins → Go → Browse → Excel/QksExcelAddIn-AddIn64-packed.xll. Viewer phải ghi PREVIEW 3. Không cần deploy AutoCAD cho viewer ETABS.

Đọc Docs/VIEWER-PREVIEW-3.md để xem thay đổi, cài đặt và phạm vi. Docs/PREVIEW-3-HOST-TESTS.md là các test Windows còn phải chạy, không phải các test đã đạt.

Thử offline: mở Samples/viewer-readonly.json rồi Samples/viewer-draft.qksdraft.json hoặc viewer-wind-line.qksdraft.json. User Loads: mở Samples/viewer-wind-source.json và vào Gió → User Loads/diaphragm → Mở gió → Samples/viewer-user-wind.qkswind.json. Tất cả là dữ liệu nhân tạo; không gán vào model thật.

Thử Apply: dùng bản sao model ETABS đã lưu, chọn đúng API, đọc model và tự soạn nháp thực. Apply kiểm tra lại nguồn, backup SHA-256, return codes/read-back, khôi phục đơn vị và ghi journal trong QKS_Backups cạnh model. Nếu lỗi giữa chừng, model có thể đã thay đổi một phần; không tự thử lại Add. Đọc báo cáo và kiểm tra backup.

Chưa có engine tự tính TCVN 2737:2023, tự lấy tâm cứng/khóa tầng hoặc adapter live SAFE. T1 chỉ tham chiếu; p/F phải từ nguồn tính đã kiểm chứng. User Loads chỉ sửa khóa API đã có. Dùng pattern riêng cho gió dầm biên và User Loads.

Validation chứa 194 core/VM tests đạt, log build, benchmark dữ liệu nhân tạo và chữ ký SDK ETABS. Cloud không chạy WPF/Excel/CSI Windows; đây là bản thử chưa nghiệm thu host. manifest.json ghi commit nguồn và SHA-256 từng file.
