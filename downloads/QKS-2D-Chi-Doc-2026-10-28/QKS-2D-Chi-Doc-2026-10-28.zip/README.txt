QKS 2D - BAN CHI DOC - 28/10/2026

Cua so Mo hinh 2D khong con chuc nang nhap/gan tai, nhap, Apply hay mo/luu file snapshot. Van doc mo hinh ETABS da ket noi de ve Plan/Elevation va xem tai da doc. Du lieu doc tam thoi ton tai trong bo nho khi su dung; khong tu tao file snapshot.

Dong Excel, bo nap QKS cu, giai nen va chon Excel/QksExcelAddIn-AddIn64-packed.xll trong Excel Options > Add-ins > Manage Excel Add-ins > Go > Browse. Tieu de cua so: QUAN LY TAI TRONG 2D - CHI DOC.

Ban nay chua hoan thien xuat thuyet minh, SAFE live, hoac doc moi loai tai. API hien doc tai phan bo tren frame va tai deu tren area; xem Chan doan de biet pham vi. Module tai khac cua QKS khong thuoc thay doi nay.

291/291 core/VM tests; build 0 warning/error. Chua chay WPF/Excel/ETABS tren Windows; can kiem tra tren may that.
Nguon build: b8df148f810f1c2a2be74be31419e5981aaa768f
