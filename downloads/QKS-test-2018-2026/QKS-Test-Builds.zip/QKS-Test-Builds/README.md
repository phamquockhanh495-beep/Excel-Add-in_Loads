# QKS — gói kiểm thử Windows x64

Đã compile, chưa thử host Windows. Gồm XLL Excel 64-bit và adapter riêng cho AutoCAD 2018–2026.

Cài một lần: đóng Excel/AutoCAD, chép hai thư mục Excel và AutoCAD vào C:\QKS_JSON_Data\Loads, giữ nguyên cấu trúc thư mục năm. Nạp Excel\QksExcelAddIn-AddIn64-packed.xll. Sau đó chọn model/bản vẽ qua Kết Nối API trên Ribbon; Excel tự chọn và nạp plugin CAD khi thao tác. Không cần chạy PowerShell mỗi lần sử dụng.

Script scripts/deploy-local.ps1 là lựa chọn thay cho chép thủ công, có kiểm tra hash và sao lưu bản cũ. Nếu dùng script với gói nhiều adapter, chọn năm, ví dụ -AcadVersion 2024.

Đọc BUILD-AND-TEST.md trước thử trên model test. Tải gió và tạo sàn ảo vùng chữ nhật đang tạm ngừng.
