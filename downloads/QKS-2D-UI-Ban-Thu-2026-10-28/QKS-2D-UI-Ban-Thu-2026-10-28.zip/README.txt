QKS 2D - BAN THU GIAO DIEN 28/10/2026

Ban thu nay gom cac thay doi da build: nut banh rang mo tuy chon lop/hien thi va can giua/gian cot mot so bang quan ly. Giao dien chua duoc kiem tra tren Windows; headbar van ghi PREVIEW 5.1.

CHUA HOAN THANH: tim kiem theo tab, tach quan ly Dam/Tuong-San-Gio, mau theo Object va Extrude. Khong xem day la ban hoan chinh. SAFE live chua duoc xac minh.

Dong Excel, bo nap XLL cu, giai nen vao thu muc co dinh; neu co Unblock trong Properties cua ZIP thi bo chan. Trong Excel Options > Add-ins > Manage Excel Add-ins > Go > Browse, chon Excel/QksExcelAddIn-AddIn64-packed.xll. Du lieu Samples la nhan tao, dung de thu offline.

Build Windows-targeted tren Linux, 0 warnings/errors; chua chay WPF/Excel/ETABS tren Windows. Thu Apply tren ban sao mo hinh da luu.
Ma nguon: aaaac813bbf8f8ecfe8b4c9659bd82a00d561c2f
