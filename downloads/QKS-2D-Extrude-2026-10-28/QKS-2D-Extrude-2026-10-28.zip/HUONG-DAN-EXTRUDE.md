# QKS 2D — Extrude và thiết lập hiển thị

## Thay đổi

- Đưa cột trở lại mô hình, bộ lọc, danh sách và chức năng chọn cấu kiện.
- Đọc kích thước theo property qua API ETABS, cache trong mỗi lần đọc, đổi về mét theo đơn vị hiện hành. Không suy đoán kích thước từ tên tiết diện; không đổi đơn vị hay ghi vào ETABS.
- Dầm/cột/giằng tiết diện chữ nhật và tròn: chiếu khối tiết diện, xét góc local axes thông thường và dải xem. Mặt bằng thể hiện bề rộng dầm, tiết diện cột; mặt đứng thể hiện chiều cao dầm.
- Sàn đặc/vách có chiều dày cố định: giữ polygon mặt (kể cả lõm), thể hiện chiều dày khi nhìn cạnh. Khoét opening đồng phẳng khỏi phần tô mặt và loại khỏi vùng chọn bên trong lỗ.
- Chọn bằng click/quét theo hình Extrude; snap dựng mặt đứng vẫn theo trục/biên phân tích.
- Bảng settings riêng từng loại: Hiện, Extrude, Label, UniqueName, Section/Property. Có công tắc Extrude tổng và chế độ màu Property/loại cấu kiện.
- Nền xanh xám sáng; dầm cyan, cột/vách xám, sàn tím nhạt, chọn cam. Chữ navy, giữ hướng theo dầm.
- Button navy, bo góc 3 DIP, giảm bóng; combobox/textbox MaterialDesign có viền; nút settings dùng PackIcon. Thuộc tính mở sẵn, hiển thị kích thước đã đọc.

## Phạm vi cần hiểu khi kiểm tra

Extrude là biểu diễn quanh **trục hoặc mặt tham chiếu phân tích**, chưa dựng vị trí vật lý có insertion point, eccentricity hay end offsets. Tiết diện tròn được xấp xỉ 48 cạnh. Chưa dựng I/T/L, section designer, tiết diện biến đổi, advanced local axes, sàn gân/waffle, hoặc shell nghiêng so với mặt nhìn; trường hợp chưa hỗ trợ giữ đường trục/biên. Không được dùng hình này để kiểm tra va chạm vật lý/BIM.

Opening đồng phẳng được trừ khỏi mặt tô; hình cắt cạnh sàn/vách chưa trừ khối lỗ xuyên chiều dày. Các nhãn và settings áp dụng trong phiên cửa sổ, chưa lưu profile.

Không thêm LOAD STRIP, nội lực/moment, thép thiết kế hoặc xuất AutoCAD từ ảnh tham khảo. Workspace tiếp tục quản lý tải đã đọc, không có gán tải hoặc file snapshot. Adapter SAFE live vẫn cần triển khai/kiểm chứng riêng.

## Kiểm tra Windows

1. Tắt Excel, bỏ chọn add-in QKS cũ, giải nén và Browse `Excel/QksExcelAddIn-AddIn64-packed.xll` trong Excel desktop 64-bit.
2. Kết nối API đúng workbook và model ETABS; mở mô hình 2D để đọc dữ liệu mới.
3. Chọn dầm chữ nhật đã biết kích thước; bật/tắt Extrude, đối chiếu Plan (b) và Elevation (h). Xem kích thước trong panel Thuộc tính.
4. Kiểm tra cột chữ nhật/tròn, cột xoay local angle; vách nhìn Plan và sàn nhìn Elevation. Kiểm tra Chẩn đoán với tiết diện chưa hỗ trợ.
5. Trong bánh răng, bật/tắt Hiện/Extrude/Label/UniqueName/Section từng dòng. Thử Property color; kiểm tra dropdown, focus/hover và popup ở DPI 100/125/150%.
6. Click vào bề rộng dầm, quét hai chiều; Ctrl chọn nhiều, Esc bỏ chọn, Delete/Khôi phục. Chọn 2 điểm phải snap theo trục.
7. Kiểm tra slab có lỗ mở, mặt lõm, vùng zoom sâu và mô hình lớn. Đối chiếu tải đọc trước/sau; mô hình ETABS không bị sửa.

## Xác minh cloud

Build Release .NET Framework 4.8, packed XLL x64; core/VM tests có hình học rectangle/circle, local rotation, dầm xiên, clipping, sàn/vách, opening, selection, snap và settings riêng. Log trong ZIP.

Cloud không chạy được WPF, Excel hay ETABS trên Windows; kết quả build/core test chưa thay thế nghiệm thu tương tác/API thực tế.
