using System;
using System.Linq;
using QksExcelAddIn.Modeling.Core;
using QksExcelAddIn.ViewModels;

internal static partial class Program
{
    private static ProjectedElement PlanGeometry(params Vec3[] vertices)
    {
        var element=new ModelElement(vertices.Length==2?"Frame:pick":"Area:pick","pick","B1","L1","B200",vertices.Length==2?ElementKind.Beam:ElementKind.Slab,vertices);
        return Projection.Build(element,ViewPlane.Plan(0,.1));
    }
    private static void InteractionTests()
    {
        Check("selection: left window requires full beam; right crossing accepts intersection",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,0,0));var b=new Box2(new Vec2(2,-1),new Vec2(8,1));Assert(!ViewerSelection.InBox(e,b,false)&&ViewerSelection.InBox(e,b,true));});
        Check("selection: full containment and boundary touch accepted",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,0,0));var b=new Box2(new Vec2(0,-1),new Vec2(10,1));Assert(ViewerSelection.InBox(e,b,false));Assert(ViewerSelection.InBox(e,new Box2(new Vec2(10,0),new Vec2(12,2)),true));});
        Check("selection: crossing diagonal with no endpoint inside",()=>{var e=PlanGeometry(new Vec3(-10,-10,0),new Vec3(10,10,0));var b=new Box2(new Vec2(-1,-1),new Vec2(1,1));Assert(ViewerSelection.InBox(e,b,true)&&!ViewerSelection.InBox(e,b,false));});
        Check("selection: rectangle wholly inside a slab counts only for crossing",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,0,0),new Vec3(10,10,0),new Vec3(0,10,0));var b=new Box2(new Vec2(3,3),new Vec2(4,4));Assert(ViewerSelection.InBox(e,b,true)&&!ViewerSelection.InBox(e,b,false));});
        Check("selection: empty concave recess is not selected by crossing",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(4,0,0),new Vec3(4,1,0),new Vec3(1,1,0),new Vec3(1,4,0),new Vec3(0,4,0));Assert(!ViewerSelection.InBox(e,new Box2(new Vec2(2,2),new Vec2(3,3)),true));});
        Check("selection: reverse drag has normalized geometry bounds",()=>{var a=new Box2(new Vec2(5,5),new Vec2(1,1));Assert(a.Contains(new Vec2(2,2))&&a.Left==1&&a.Top==5);});
        Check("selection: parallel outside segment stays outside",()=>{Assert(!ViewerSelection.Intersects(new Segment2(new Vec2(0,5),new Vec2(10,5)),new Box2(new Vec2(1,1),new Vec2(2,2))));});
        Check("selection: collapsed point is selected only when inside",()=>{var e=PlanGeometry(new Vec3(2,2,-1),new Vec3(2,2,1));Assert(ViewerSelection.InBox(e,new Box2(new Vec2(1,1),new Vec2(3,3)),false));Assert(!ViewerSelection.InBox(e,new Box2(new Vec2(4,4),new Vec2(5,5)),true));});
        Check("selection: click inside area and edge tolerance",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(4,0,0),new Vec3(4,4,0),new Vec3(0,4,0));Assert(ViewerSelection.Hit(e,new Vec2(2,2),.1));Assert(ViewerSelection.Hit(e,new Vec2(4.05,2),.1));Assert(!ViewerSelection.Hit(e,new Vec2(5,2),.1));});
        Check("selection: Ctrl toggles one ID while keeping others",()=>{var a=ViewerSelection.Change(new[]{"a","b"},new[]{"b","c"},SelectionChange.Toggle);Assert(a.SequenceEqual(new[]{"a","c"}));});
        Check("selection: Ctrl window adds without removing existing IDs",()=>{var a=ViewerSelection.Change(new[]{"a","b"},new[]{"b","c","c"},SelectionChange.Add);Assert(a.SequenceEqual(new[]{"a","b","c"}));});
        Check("selection: plain click and empty click replace selection",()=>{Assert(ViewerSelection.Change(new[]{"a","b"},new[]{"c"},SelectionChange.Replace).SequenceEqual(new[]{"c"}));Assert(ViewerSelection.Change(new[]{"a"},Array.Empty<string>(),SelectionChange.Replace).Length==0);});
        Check("selection VM: multi-select highlights multiple but disables single editor",()=>{var vm=new VisualWorkspaceViewModel();vm.SetSnapshot(DraftFixture(),true);vm.SelectElements(new[]{"Frame:B1","Frame:B2"});Assert(vm.SelectedElements.Count==2&&!vm.CanEditDraft&&vm.Inspector.Contains("2 cấu kiện"));vm.SelectElements(new[]{"Frame:B2"},SelectionChange.Toggle);Assert(vm.SelectedId=="Frame:B1"&&vm.CanEditDraft);});
        Check("selection VM: hidden columns and unknown IDs cannot enter set",()=>{var vm=new VisualWorkspaceViewModel();vm.SetSnapshot(DraftFixture(),true);vm.SelectElements(new[]{"Frame:C1","missing","Frame:B1"});Assert(vm.SelectedIds.SequenceEqual(new[]{"Frame:B1"}));});
        Check("selection VM: Delete-style clear does not modify model or draft",()=>{var vm=new VisualWorkspaceViewModel();vm.SetSnapshot(DraftFixture(),true);vm.Drafts.Put(Slab());string fp=SnapshotFingerprint.Of(vm.Snapshot);vm.SelectElements(new[]{"Frame:B1","Area:S1"});vm.ClearSelection();Assert(vm.SelectedIds.Count==0&&vm.DraftRows.Count==1&&SnapshotFingerprint.Of(vm.Snapshot)==fp);});
        Check("selection VM: selection survives view/filter, resets on model read",()=>{var vm=new VisualWorkspaceViewModel();vm.SetSnapshot(DraftFixture(),true);vm.SelectElements(new[]{"Frame:B1","Area:S1"});vm.Elevation=true;vm.Kind="Beam";Assert(vm.SelectedIds.Count==2);vm.SetSnapshot(DraftFixture(),true);Assert(vm.SelectedIds.Count==0);});
        Check("selection VM: tables filter loads to selected IDs",()=>{var vm=new VisualWorkspaceViewModel();vm.SetSnapshot(DraftFixture(),true);vm.SelectElements(new[]{"Frame:B1","Area:S1"});Assert(vm.VisibleLoads.Count()==2&&vm.ComparisonRows.All(r=>r.Load.ElementId!="Frame:B2"));});
        Check("snap: endpoint wins within tolerance",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,0,0));var s=ModelSnap.Find(new[]{e},new Vec2(.03,.01),.1);Assert(s.Kind==SnapKind.Endpoint);Near(s.Point.X,0);});
        Check("snap: midpoint is available without a source joint",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,0,0));var s=ModelSnap.Find(new[]{e},new Vec2(5.02,.01),.1);Assert(s.Kind==SnapKind.Midpoint);Near(s.Point.X,5);});
        Check("snap: nearest point on oblique member",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,10,0));var s=ModelSnap.Find(new[]{e},new Vec2(3,3.1),.2);Assert(s.Kind==SnapKind.Edge);Near(s.Point.X,3.05);Near(s.Point.Y,3.05);});
        Check("snap: tolerance follows zoom and does not snap distant cursor",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(10,0,0));Assert(ModelSnap.Find(new[]{e},new Vec2(3,.2),.1)==null);Assert(ModelSnap.Find(new[]{e},new Vec2(3,.2),.4)!=null);});
        Check("snap: slab boundary can define elevation points",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(4,0,0),new Vec3(4,4,0),new Vec3(0,4,0));var s=ModelSnap.Find(new[]{e},new Vec2(4,1.2),.1);Assert(s.Kind==SnapKind.Edge&&s.ElementId=="Area:pick");var plane=ViewPlane.ElevationThrough(new Vec2(0,0),s.Point,.1);Near(plane.Depth(new Vec3(4,1.2,6)),0);});
        Check("labels: rectangle slab anchor is centroid, not first edge",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(6,0,0),new Vec3(6,4,0),new Vec3(0,4,0));var p=ElementLabels.Anchor(e);Near(p.X,3);Near(p.Y,2);});
        Check("labels: triangle centroid and winding invariance",()=>{var vertices=new[]{new Vec3(0,0,0),new Vec3(6,0,0),new Vec3(0,3,0)};var p=ElementLabels.Anchor(PlanGeometry(vertices));Near(p.X,2);Near(p.Y,1);var r=ElementLabels.Anchor(PlanGeometry(vertices.Reverse().ToArray()));Near(r.X,2);Near(r.Y,1);});
        Check("labels: concave polygon uses area-weighted centroid",()=>{var p=ElementLabels.Anchor(PlanGeometry(new Vec3(0,0,0),new Vec3(4,0,0),new Vec3(4,1,0),new Vec3(1,1,0),new Vec3(1,4,0),new Vec3(0,4,0)));Near(p.X,19.0/14);Near(p.Y,19.0/14);});
        Check("labels: beam midpoint and raw name/property options",()=>{var e=PlanGeometry(new Vec3(0,0,0),new Vec3(6,2,0));Near(ElementLabels.Anchor(e).X,3);Near(ElementLabels.Anchor(e).Y,1);Assert(ElementLabels.Text(e.Source,false,true,true)=="B200\npick");Assert(!ElementLabels.Text(e.Source,true,true,true).Contains("Frame:"));});
        Check("labels: repeated Label and Name are not duplicated",()=>{var e=new ModelElement("Frame:B1","B1","B1","L1","D200",ElementKind.Beam,new[]{new Vec3(0,0,0),new Vec3(1,0,0)});Assert(ElementLabels.Text(e,true,false,true)=="B1");});
    }
}
