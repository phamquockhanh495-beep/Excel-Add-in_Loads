# QKS 2D Preview 5 — Excel Windows x64

1. Đóng toàn bộ Excel. Nếu có Unblock trong Properties của ZIP, bỏ chặn rồi giải nén vào thư mục cố định.
2. Bỏ nạp QKS cũ. Excel → File → Options → Add-ins → Manage Excel Add-ins → Go → Browse.
3. Chọn Excel/QksExcelAddIn-AddIn64-packed.xll. Headbar phải ghi PREVIEW 5.
4. Kết nối API chọn workbook Excel và model ETABS. Mở viewer để tự đọc, không cần Đọc lại lần đầu.
5. Có thể mở Samples/viewer-readonly.json để thử offline theo Docs/VIEWER-PREVIEW-5.md.

Delete chỉ bỏ cấu kiện khỏi workspace 2D; Khôi phục để hiện lại. Không xóa model/tải/nháp.
Nháp giữ nguyên và vẫn tham gia Apply; muốn bỏ tải đã soạn thì xóa dòng nháp riêng.
Badge tập chọn nằm dưới trái. Chữ xoay theo dầm, giữ cỡ chữ khi zoom, không tự ẩn vì chật.
File tính lấy đúng workbook API; model kết nối tự đọc khi mở viewer hoặc đổi API.
Đổi riêng workbook/CAD không đọc lại hình học. Chọn model khác trong ComboBox viewer thì bấm Đọc lại.

Gió tiếp tục nhập trực tiếp từ Excel/CSV/popup theo Story, không quy đổi. Xem Docs/WIND-STORY-INPUT.md.
Mẫu Excel là mẫu trống theo Story nhân tạo; hai CSV chỉ dùng với snapshot offline tương ứng.
User Loads cần khóa API đã đọc và đối chiếu Story thủ công; chưa tự tạo khóa hoặc lấy tâm cứng.

291/291 core/VM tests; packed XLL build 0 warning/error. Logs/benchmark trong Validation chỉ đo core/VM
trên Linux, không đo WPF FPS hoặc xác nhận tương thích host. Cloud chưa chạy Excel/WPF/ETABS;
cần kiểm tra gesture, font/DPI, nhãn zoom và tự đọc API trên Windows. Chưa khẳng định giống ETABS 100%.
SAFE live chưa xác minh; plugin CAD không thay đổi, không cần deploy AutoCAD để dùng viewer ETABS.
Khi thử Apply, dùng bản sao model đã lưu và kiểm tra backup/read-back.

Nguồn build: 315f4e2a84cfecbef8ef1b3446173d60aaceeab8
