QKS 2D Preview 2.1 - compact QKS titlebar/tabs, hidden columns, monitor/DPI sizing

1. Close all Excel windows. Extract this package into a permanent folder.
2. Excel > File > Options > Add-ins > Excel Add-ins > Go. Disable the old QKS XLL, Browse to Excel/QksExcelAddIn-AddIn64-packed.xll.
3. Extension QKS > Mo Hinh 2D. Confirm PREVIEW 2.1.
4. Hien thi > File snapshot > Mo snapshot: viewer-readonly.json.
5. Tai / thuoc tinh > Mo nhap: viewer-draft.qksdraft.json.

The titlebar has only window controls. API/read/file commands are in the side panels.
Hien thi and Tai / thuoc tinh buttons show hidden panels on narrow screens.
Columns are hidden in the UI; source snapshot and draft fingerprints remain intact.
Both fixtures are synthetic OFFLINE data. Draft operations do not write CSI models.
Read REPORT-AND-INSTALL.md for Vietnamese changes/install/DPI checks; DRAFT-WORKFLOW.md covers the draft workflow.
130 core/VM tests passed, XLL build 0 warnings/errors. Actual Windows UI/Win32/DPI and CSI host execution are not validated in cloud.
Source commit: db7ee81a80fffe5e57082d46278f9ec0753c075e
