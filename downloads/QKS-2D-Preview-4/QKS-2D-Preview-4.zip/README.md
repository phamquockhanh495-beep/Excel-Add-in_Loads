# QKS 2D Preview 4 — cài thử trên Excel Windows 64-bit

1. Đóng toàn bộ Excel. Nếu có Unblock trong Properties của ZIP, bỏ chặn rồi giải nén vào thư mục cố định.
2. Bỏ nạp QKS cũ. Excel → File → Options → Add-ins → Manage Excel Add-ins → Go → Browse.
3. Chọn Excel/QksExcelAddIn-AddIn64-packed.xll. Headbar viewer phải ghi PREVIEW 4.
4. Mở Samples/viewer-readonly.json trong viewer và thử offline theo Docs/VIEWER-PREVIEW-4.md.
5. Kết nối ETABS: chọn đúng file/PID trong ComboBox rồi Đọc lại. Không cần script deploy AutoCAD.

Thay đổi: quét Window/Crossing, Ctrl chọn nhiều, Delete hủy chọn; snap chọn hai điểm, mốc Story mặt đứng;
nhãn Section/UniqueName, bảng cao hơn 1,25 lần và dữ liệu chữ thường. Gió nhập q/F/M trực tiếp từ Excel/CSV
hoặc popup theo Story, không quy đổi áp lực hoặc tự tính TCVN. Đọc Docs/WIND-STORY-INPUT.md trước khi nhập.

Samples/wind-story-template.xlsx là mẫu TRỐNG theo tầng của snapshot nhân tạo; nên xuất mẫu từ popup
để lấy Story của model thật. Hai CSV có tên/khóa nhân tạo, chỉ dùng với các snapshot mẫu tương ứng.
User Loads cần khóa API đã đọc và ánh xạ Story do người dùng đối chiếu. Chưa tự tạo khóa/lấy tâm cứng.

255/255 core/VM tests đạt; build 0 warning/error; workbook mở được bằng bộ đọc độc lập. Logs/benchmark
trong Validation chỉ đo core/VM trên Linux, không chứng minh FPS, gesture hoặc tương thích host.
Cloud chưa chạy Excel/WPF/ETABS. Cần thử font, DPI, snap, gesture và đọc vùng Excel trên Windows;
chưa xác nhận giống ETABS 100%. SAFE live chưa có adapter xác minh. Plugin CAD không thay đổi.
Khi thử Apply, dùng bản sao model ETABS đã lưu; kiểm tra backup và read-back.

Nguồn build: 6673e845dcfd300402b1be101da854146a6c6df6
