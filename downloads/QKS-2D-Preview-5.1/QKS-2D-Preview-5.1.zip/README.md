# QKS 2D Preview 5.1 — Esc bỏ chọn

Đóng toàn bộ Excel, bỏ nạp XLL cũ, bỏ chặn ZIP nếu có mục Unblock, rồi giải nén vào thư mục cố định.
Excel → Options → Add-ins → Manage Excel Add-ins → Go → Browse tới Excel/QksExcelAddIn-AddIn64-packed.xll.
Headbar phải ghi PREVIEW 5.1.

Chọn một hoặc nhiều dầm/sàn trên hình hoặc bảng nguồn → Esc để bỏ toàn bộ tập chọn.
Esc đồng thời hủy quét/pan/chọn hai điểm mặt đứng. Khi đang nhập ô dữ liệu hoặc mở dropdown, giữ xử lý Esc của control.
Esc không bỏ cấu kiện khỏi workspace và không xóa tải/nháp; Delete/Khôi phục giữ nguyên chức năng Preview 5.

Xem Docs/VIEWER-PREVIEW-5.1.md để thử tính năng mới; Docs/VIEWER-PREVIEW-5.md mô tả đầy đủ viewer.
Samples là dữ liệu nhân tạo để thử offline, không dùng gán vào model thật.
291/291 core/VM tests đạt; build packed XLL 0 warning/error. Cloud chưa chạy WPF/Excel/ETABS trên Windows;
cần thử phím Esc và focus trên máy thật. SAFE live chưa xác minh. Plugin CAD không thay đổi.

Nguồn build: d15379f418a1cbce3d024538685f98800dd49692
