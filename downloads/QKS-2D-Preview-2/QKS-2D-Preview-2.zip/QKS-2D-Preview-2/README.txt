QKS 2D Preview 2 - Wall/slab load drafts - Excel 64-bit / Windows

1. Close Excel and extract to a permanent folder.
2. Excel > File > Options > Add-ins > Excel Add-ins > Go. Disable the old QKS XLL and Browse to Excel/QksExcelAddIn-AddIn64-packed.xll.
3. Extension QKS > Mo Hinh 2D. Check PREVIEW 2 in the header.
4. Mo snapshot > viewer-readonly.json (synthetic OFFLINE source).
5. Mo nhap > viewer-draft.qksdraft.json. B1/SDL: 8 to 10 kN/m over 1 to 5 metres; S1/LL: 4 kN/m2. See Nhap / So sanh > Truoc / Sau.

Both fixtures are synthetic, not extracted from a real CSI model.
Read REPORT-AND-INSTALL.md for Vietnamese instructions, Add/Replace semantics and stage progress.
Draft operations do not write ETABS/SAFE; there is no Apply in this viewer.
Snapshot and draft JSON files are saved separately. Wrong-source drafts are rejected or detached.
No AutoCAD/deploy-local script is required for the viewer.
117 core/VM tests passed; build 0 warnings/errors. Windows UI/CSI COM execution has not been validated in cloud.
Source commit: 3402fe9fc00d674803936d86fba699f8086af138
