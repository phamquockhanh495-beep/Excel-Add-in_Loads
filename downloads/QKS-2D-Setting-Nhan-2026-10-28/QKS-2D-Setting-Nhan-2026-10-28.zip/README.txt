QKS 2D - SETTING NHAN THEO LOAI CAU KIEN - 28/10/2026

Cua so 2D chi doc. Nut banh rang: tuy chon Label, UniqueName, Section/Property doc lap cho dam, san, vach, giang, opening va loai khac. Day la tuy chon theo loai, ap dung cho moi cau kien cung loai; khong phai tuy chon rieng tung ID. Cai dat duoc giu trong khi cua so dang mo, chua luu thanh profile sau khi dong.

Dong Excel, bo nap XLL cu, giai nen; neu ZIP co Unblock thi bo chan. Excel Options > Add-ins > Manage Excel Add-ins > Go > Browse toi Excel/QksExcelAddIn-AddIn64-packed.xll. Neu doi ngay sau khi ket noi, danh dau va bo danh dau cac muc trong nut banh rang de kiem tra.

292/292 core/VM tests, build 0 warning/error. Chua kiem tra WPF/Excel/ETABS tren Windows. SAFE live va xuat thuyet minh chua hoan tat.
Nguon: 59d8cd5359e0a0d5c67be17db3a59a8e929b84ac
