QKS 2D Preview 1.1 - Material Design - Excel 64-bit / Windows

1. Close Excel and extract to a permanent folder.
2. Excel > File > Options > Add-ins > Excel Add-ins > Go. Disable the old QKS XLL; Browse to Excel/QksExcelAddIn-AddIn64-packed.xll.
3. Extension QKS > Mo Hinh 2D. Check PREVIEW 1.1 in the header.
4. Mo snapshot > viewer-readonly.json for the synthetic OFFLINE fixture.

Material Design controls follow WallLoadView/ShellLoadView formatting, with QKS navy and 3 DIP button corners.
Read REPORT-AND-INSTALL.md for Vietnamese change notes and READONLY-VIEWER-SCOPE.md for feature scope.
No AutoCAD plugin/deploy script is required for the viewer.
Build + 73 core/VM tests passed. Windows rendering/ripple/DPI and CSI host execution have not been validated in cloud.
Source commit: bc76cb74e0b1ac791b8057536d59deae95a285a7
