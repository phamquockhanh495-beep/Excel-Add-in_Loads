QKS 2D Preview 1 - Excel 64-bit / Windows

1. Close Excel and extract this package to a permanent folder.
2. Excel > File > Options > Add-ins > Excel Add-ins > Go. Disable the previous QKS XLL, then Browse to Excel/QksExcelAddIn-AddIn64-packed.xll.
3. Extension QKS > Mo Hinh 2D > Mo snapshot > viewer-readonly.json (OFFLINE synthetic fixture).
4. For live data, select ETABS using Ket Noi API, then Doc mo hinh.

Read REPORT-AND-INSTALL.md for Vietnamese instructions and limitations.
No AutoCAD plugin/deploy script is needed for this viewer.
Read-only preview: no draft/Apply. SAFE 18-22 / 22.5 support is planned, not implemented here.
Build + 73 core/VM tests passed; Excel/WPF/CSI host execution has not been tested on Windows.
Source commit: 2c6092d2fa8070aca6c41fd313a8df250b808e92
